import { makeStyles } from '@mui/styles';

export default makeStyles(() => ({
  container: {
    margin: '20px 0',
  },
}));
